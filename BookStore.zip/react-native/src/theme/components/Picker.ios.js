// @flow

export default () => {
  const pickerTheme = {};

  return pickerTheme;
};
