﻿namespace Sideas.BookStore
{
    public abstract class BookStoreApplicationTestBase : BookStoreTestBase<BookStoreApplicationTestModule> 
    {

    }
}
