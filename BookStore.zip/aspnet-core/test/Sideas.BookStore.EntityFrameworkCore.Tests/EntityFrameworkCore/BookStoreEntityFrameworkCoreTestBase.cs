﻿using Volo.Abp;

namespace Sideas.BookStore.EntityFrameworkCore
{
    public abstract class BookStoreEntityFrameworkCoreTestBase : BookStoreTestBase<BookStoreEntityFrameworkCoreTestModule> 
    {

    }
}
