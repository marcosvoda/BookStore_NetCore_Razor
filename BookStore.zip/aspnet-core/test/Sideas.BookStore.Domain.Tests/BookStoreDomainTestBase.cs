﻿namespace Sideas.BookStore
{
    public abstract class BookStoreDomainTestBase : BookStoreTestBase<BookStoreDomainTestModule> 
    {

    }
}
