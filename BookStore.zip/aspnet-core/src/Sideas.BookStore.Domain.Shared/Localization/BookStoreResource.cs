﻿using Volo.Abp.Localization;

namespace Sideas.BookStore.Localization
{
    [LocalizationResourceName("BookStore")]
    public class BookStoreResource
    {

    }
}