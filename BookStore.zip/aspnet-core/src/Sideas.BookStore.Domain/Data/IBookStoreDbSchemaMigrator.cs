﻿using System.Threading.Tasks;

namespace Sideas.BookStore.Data
{
    public interface IBookStoreDbSchemaMigrator
    {
        Task MigrateAsync();
    }
}
